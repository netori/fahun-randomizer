Convergence Class Item Randomizer  v1.0.0
==========================================

Randomizes the class-guide items of The Convergence (法魂) - items only,
never locations, quantities, prices or shops.

LANGUAGE NOTICE: CHINESE-LOCALIZED BUILD ONLY. There is no English version yet.
This tool is built for the Chinese localization (法魂 / 汉化本体) of The Convergence.

INSTALL
  1. Put ConvergenceClassItemRandomizer.exe in the MOD ROOT folder
     (the folder that contains mod\regulation.bin).
  2. Run it. The "Local Files" panel checks everything it needs.
  3. Pick categories -> pick a mixing mode -> set coherence -> set a seed.
  4. Click (1) Generate plan, then (2) Write to game.
  5. Not happy? Click "Restore original".

NOTES
  * Modifies data files only (mod\regulation.bin and the guide msg file).
    Does not modify the game itself.
  * Backs up your original files before the first write.
  * Single-player only. Back up your save.
  * The UI is Chinese.

  Homepage: https://github.com/netori/fahun-randomizer
